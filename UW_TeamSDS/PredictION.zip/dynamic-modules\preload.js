define([], function(){
  //these modules will be loaded before jimu.main
});