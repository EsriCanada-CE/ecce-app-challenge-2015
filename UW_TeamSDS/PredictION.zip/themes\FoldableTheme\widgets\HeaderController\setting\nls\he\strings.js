﻿define(
   ({
    group: "שם",
    openAll: "פתח הכל בפאנל",
    dropDown: "הצג בתפריט נפתח",
    noGroup: "לא הוגדרה קבוצת וידג\'טים.",
    groupSetLabel: "הגדר תכונות של קבוצות וידג\'טים"
  })
);