﻿define(
   ({
    _widgetLabel: "Over"
  })
);