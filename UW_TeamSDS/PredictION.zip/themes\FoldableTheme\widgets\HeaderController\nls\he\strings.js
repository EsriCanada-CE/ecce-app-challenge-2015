﻿define(
   ({
    _widgetLabel: "רצועת כלים עליונה",
    signin: "התחבר",
    signout: "התנתק",
    about: "אודות",
    signInTo: "התחבר אל",
    cantSignOutTip: "פונקציה זו אינה זמינה במצב תצוגה מקדימה."
  })
);
