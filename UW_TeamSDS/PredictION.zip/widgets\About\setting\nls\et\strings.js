﻿define(
   ({
    instruction: "Looge selles vidinas kuvatavat sisu.",
    defaultContent: "Siia saate lisada teksti, lingid ja väiksemad pildid."
  })
);