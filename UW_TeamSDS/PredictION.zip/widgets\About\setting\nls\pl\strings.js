﻿define(
   ({
    instruction: "Utwórz treści, które zostaną pokazane w tym widżecie.",
    defaultContent: "Tutaj możesz dodać tekst, łącza oraz niewielkie elementy graficzne."
  })
);