﻿define(
   ({
    _widgetLabel: "وحدة تحكم العنوان",
    signin: "تسجيل الدخول",
    signout: "تسجيل الخروج",
    about: "نبذة عن",
    signInTo: "تسجيل الدخول إلى",
    cantSignOutTip: "يتم تطبيق هذه الوظيفة في وضع المعاينة."
  })
);
