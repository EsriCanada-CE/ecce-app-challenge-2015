﻿define(
   ({
    instruction: "Creare contenuti che verranno visualizzati in questo widget.",
    defaultContent: "Aggiungere qui testo, collegamenti e piccole immagini."
  })
);