﻿define(
   ({
    _widgetLabel: "Aluskaardigalerii"
  })
);