﻿define(
   ({
    _themeLabel: "Сворачиваемая тема",
    _layout_default: "Компоновка по умолчанию",
    _layout_layout1: "Компоновка 1"
  })
);