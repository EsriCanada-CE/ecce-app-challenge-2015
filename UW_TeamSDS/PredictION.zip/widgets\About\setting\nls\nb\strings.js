﻿define(
   ({
    instruction: "Opprett innhold som skal vises i dette miniprogrammet.",
    defaultContent: "Legg til tekst, koblinger og små grafikkelementer her."
  })
);