﻿define(
   ({
    _widgetLabel: "O aplikaci"
  })
);