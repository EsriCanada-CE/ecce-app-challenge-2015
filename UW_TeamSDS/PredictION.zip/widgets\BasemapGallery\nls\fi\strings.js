﻿define(
   ({
    _widgetLabel: "Taustakartat"
  })
);