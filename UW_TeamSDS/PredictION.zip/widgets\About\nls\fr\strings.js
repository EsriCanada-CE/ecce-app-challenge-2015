﻿define(
   ({
    _widgetLabel: "A propos"
  })
);