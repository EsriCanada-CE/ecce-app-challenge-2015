﻿define(
   ({
    _themeLabel: "Temă cu pliere",
    _layout_default: "Configuraţie implicită",
    _layout_layout1: "Aspectul 1"
  })
);