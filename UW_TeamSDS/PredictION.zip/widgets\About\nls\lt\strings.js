﻿define(
   ({
    _widgetLabel: "Apie"
  })
);