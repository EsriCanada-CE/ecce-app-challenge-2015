﻿define(
   ({
    instruction: "Bu araçta gösterilecek içeriği oluşturun.",
    defaultContent: "Buraya metin, bağlantılar ve küçük grafikler ekleyin."
  })
);