﻿define(
   ({
    instruction: "Vytvořte obsah, který se bude zobrazovat v tomto widgetu.",
    defaultContent: "Sem přidejte text, odkazy a malé obrázky."
  })
);