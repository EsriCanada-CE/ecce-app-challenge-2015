﻿define(
   ({
    group: "名前",
    openAll: "すべてをパネルで開く",
    dropDown: "ドロップダウン メニューに表示",
    noGroup: "ウィジェット グループ セットがありません。",
    groupSetLabel: "ウィジェット グループ プロパティの設定"
  })
);