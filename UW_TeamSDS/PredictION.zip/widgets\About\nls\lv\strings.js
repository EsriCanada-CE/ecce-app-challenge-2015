﻿define(
   ({
    _widgetLabel: "Par"
  })
);