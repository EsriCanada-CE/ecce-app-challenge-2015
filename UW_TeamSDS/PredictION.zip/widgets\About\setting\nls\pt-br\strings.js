﻿define(
   ({
    instruction: "Cria conteúdo que será mostrado neste widget.",
    defaultContent: "Adicione texto, links e gráficos pequenos aqui."
  })
);