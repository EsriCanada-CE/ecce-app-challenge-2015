﻿define(
   ({
    _widgetLabel: "Sobre"
  })
);