﻿define(
   ({
    instruction: "Créez le contenu qui apparaîtra dans ce widget.",
    defaultContent: "Ajoutez du texte, des liens et de petits graphiques ici."
  })
);