// Playground - noun: a place where people can play

import Cocoa
//import ArcGIS


//let gdb = AGSGDBGeodatabase(path: "test1.geodatabase", error: nil)
var routeTime:[Double] = [1.1]

func test(){
    var x = 5.5
    routeTime[0]=x
}
println(routeTime)
test()
println(routeTime)

