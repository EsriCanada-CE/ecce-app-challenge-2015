//
//  FactBook.swift
//  FunFacts
//
//  Created by Tom McKay on 2015-02-28.
//  Copyright (c) 2015 Tom McKay. All rights reserved.
//

import Foundation

struct FactBook {
    let factsArray = [
        "Welcome To QuakeReady!\n QuakeReady helps you prepare for Vancouver Earthquakes based on your location, to begin delete this app throw your phone in the garbage sell your house and move somewhere safe!"
    ]

func randomFact() -> String {
    var unsignedArrayCount = UInt32(factsArray.count)
    var unsignedRandomNumber = arc4random_uniform(unsignedArrayCount)
    var randomNumber = Int(unsignedRandomNumber)
    
    return factsArray[randomNumber]
}
}