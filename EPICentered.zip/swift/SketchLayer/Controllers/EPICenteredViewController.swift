//
// Copyright 2014 ESRI
//
// All rights reserved under the copyright laws of the United States
// and applicable international laws, treaties, and conventions.
//
// You may freely redistribute and use this sample code, with or
// without modification, provided you include the original copyright
// notice and use restrictions.
//
// See the use restrictions at http://help.arcgis.com/en/sdk/10.0/usageRestrictions.htm
//

import UIKit
import ArcGIS
import Foundation
let bundle = NSBundle.mainBundle()
let gdb1FilePath = bundle.pathForResource("eq_app_web", ofType: "geodatabase")
let gdb2FilePath = bundle.pathForResource("eq_app_web1", ofType: "geodatabase")
//import CoreLoaction

//Envelope Declaration
var env:AGSEnvelope!

//Geodatabase Layer Declarations
var clinicsLayer:AGSFeatureTableLayer!
var communityCenterLayer:AGSFeatureTableLayer!
var disasterLayer:AGSFeatureTableLayer!
var fireHallLayer: AGSFeatureTableLayer!
var hospitalLayer: AGSFeatureTableLayer!
var policeLayer: AGSFeatureTableLayer!
var schoolLayer: AGSFeatureTableLayer!
var operationsLayer: AGSFeatureTableLayer!



class SketchLayerViewController: UIViewController, AGSMapViewLayerDelegate, AGSMapViewTouchDelegate, AGSLocatorDelegate, AGSCalloutDelegate,  AGSRouteTaskDelegate {

    // ---------------------------------------  Routing Tasks Declaration
    var graphicsLayerStops:AGSGraphicsLayer!
    var graphicsLayerRoute:AGSGraphicsLayer!
    var routeTask:AGSRouteTask!
    var routeTaskParams:AGSRouteTaskParameters!
    var currentStopGraphic:AGSStopGraphic!
    var currentDirectionGraphic:AGSDirectionGraphic!
    var routeResult:AGSRouteResult!
    var lastStop:AGSGraphic!
    var mePointMark:AGSGraphic!
    var isExecuting = false
    var routeGraphic:AGSGraphic!
    var geodatabase:AGSGDBGeodatabase!
    var numStops:UInt = 0
    var directionIndex:Int = 0
    var reorderStops = false
    var empX:[Double] = [-13706657.622,-13697979.271, -13710150.129, -13698032.188,-13706684.081,-13700148.859]
    var empY:[Double] = [6322875.307,6320838.012,6319409.259,6318298.006,6311524.66,6312926.954]
    var routeTime:[Double] = [0,0,0,0,0]
    var rtPassVal:Int = 0
    var solveCount:Int = 0
    var timeCount:Int = 0
    
    let sr = AGSSpatialReference(WKID: 102100)
    
    // ----------------------------------------   end route task decalartion
    
   
    //Layer Toolbars
    @IBOutlet weak var layerOne: UIToolbar!
    @IBOutlet weak var layerTwo: UIToolbar!
    @IBOutlet weak var layerThree: UIToolbar!
    
    //Layer Toolbar Buttons
    
    //Main Toolbar Buttons
    @IBOutlet weak var legendImage: UIButton!
    @IBOutlet weak var aboutApp: UIButton!
    @IBOutlet weak var toolBar: UIToolbar!
    @IBOutlet weak var startedButton: UIButton!
    //@IBOutlet weak var introText: UILabel!
    @IBAction func getStarted(sender: UIButton) {
        introText.hidden = true
        startedButton.hidden = true
        self.mapView.zoomToEnvelope(env, animated:true)
        println(env)
    }
 
    @IBOutlet weak var mapView:AGSMapView!
    var sketchToolbar:SketchToolbar!
    var locator:AGSLocator!
    override func prefersStatusBarHidden() -> Bool {
        return true
    }

    
    override func viewDidLoad() {
        super.viewDidLoad()
        //Show magnifier to help with sketching
        //self.mapView.showMagnifierOnTapAndHold = true
        
        //Tiled basemap layer
        
        let mapUrl = NSURL(string: "http://services.arcgisonline.com/ArcGIS/rest/services/World_Topo_Map/MapServer")
        let tiledLyr = AGSTiledMapServiceLayer(URL: mapUrl)
        self.mapView.addMapLayer(tiledLyr, withName:"Tiled Layer")
        self.mapView.layerDelegate = self
        //Add Geodatabase
        var error:NSError? = nil
        let gdb1 = AGSGDBGeodatabase(path:gdb1FilePath, error: nil)
        let gdb2 = AGSGDBGeodatabase(path:gdb2FilePath, error: nil)
        println(gdb1FilePath)
        println(gdb2FilePath)
        //let gdb1 = AGSGDBGeodatabase.geodatabaseWithName("ecc_app_web", error:&error)
        
        //Add Clinics from Geodatabase
        var clinics:AGSGDBFeatureTable!
        clinics = gdb1.featureTables()[1] as AGSGDBFeatureTable
        clinicsLayer = AGSFeatureTableLayer(featureTable: clinics)
        //localFeatureTableLayer.delegate = self
        self.mapView.addMapLayer(clinicsLayer, withName:"Clinics")
        
        //Add Community Centers from Geodatabase
        var communityCenter:AGSGDBFeatureTable!
        communityCenter = gdb1.featureTables()[2] as AGSGDBFeatureTable
        communityCenterLayer = AGSFeatureTableLayer(featureTable: communityCenter)
        //localFeatureTableLayer.delegate = self
        self.mapView.addMapLayer(communityCenterLayer, withName:"CommunityCenter")
        
        //Add Disaster Muster Points from Geodatabase
        var disaster:AGSGDBFeatureTable!
        disaster = gdb1.featureTables()[3] as AGSGDBFeatureTable
        disasterLayer = AGSFeatureTableLayer(featureTable: disaster)
        //localFeatureTableLayer.delegate = self
        self.mapView.addMapLayer(disasterLayer, withName:"Disaster")
        
        //Add Fire Halls from Geodatabase
        var fireHall:AGSGDBFeatureTable!
        fireHall = gdb1.featureTables()[5] as AGSGDBFeatureTable
        fireHallLayer = AGSFeatureTableLayer(featureTable: fireHall)
        //localFeatureTableLayer.delegate = self
        self.mapView.addMapLayer(fireHallLayer, withName:"FireHall")
        
        //Add Fire Halls from Geodatabase
        var operations:AGSGDBFeatureTable!
        operations = gdb1.featureTables()[4] as AGSGDBFeatureTable
        operationsLayer = AGSFeatureTableLayer(featureTable: operations)
        //localFeatureTableLayer.delegate = self
        self.mapView.addMapLayer(operationsLayer, withName:"Operations")
        
        //Add Hospitals from Geodatabase
        var hospital:AGSGDBFeatureTable!
        hospital = gdb1.featureTables()[0] as AGSGDBFeatureTable
        hospitalLayer = AGSFeatureTableLayer(featureTable: hospital)
        //localFeatureTableLayer.delegate = self
        self.mapView.addMapLayer(hospitalLayer, withName:"Hospitals")
        
        //Add Police Stations from Geodatabase
        var police:AGSGDBFeatureTable!
        police = gdb1.featureTables()[6] as AGSGDBFeatureTable
        policeLayer = AGSFeatureTableLayer(featureTable: police)
        //localFeatureTableLayer.delegate = self
        self.mapView.addMapLayer(policeLayer, withName:"Police")
        
        //Add Schools from Geodatabase
        var school:AGSGDBFeatureTable!
        school = gdb1.featureTables()[7] as AGSGDBFeatureTable
        schoolLayer = AGSFeatureTableLayer(featureTable: school)
        //localFeatureTableLayer.delegate = self
        self.mapView.addMapLayer(schoolLayer, withName:"Schools")
        
        
        //Vancouver, BC
        let sr = AGSSpatialReference(WKID: 102100)
        env = AGSEnvelope(xmin: -13687325.75,
            ymin:6308206.25,
            xmax:-13725336.1,
            ymax:6331390.0, spatialReference:sr)
        self.mapView.zoomToEnvelope(env, animated:true)

        
        //Set user location
        mapView.locationDisplay.startDataSource()
        
        // ------------ for testing
        // ------------ the spoofed gps point
        
        var mePoint = AGSPoint(x: -13679050, y: 6300050, spatialReference: sr)
   
        // -------------------------  Routing Task Code
        

        
        // ---------                  set route task geodatabase and .tn folder
        self.routeTask = AGSRouteTask(databaseName: "eq_app_web1", network:"EQ_Feature_ND", error:&error)
        
        // -----------                assign delegate to this view controller
        self.routeTask.delegate = self
        
        // -----------                async for route tasks
        self.routeTask.retrieveDefaultRouteTaskParameters()
        
        
        
        // add graphics layer for displaying the stops
        self.graphicsLayerStops = AGSGraphicsLayer()
        
        //var OpsStopFeature = AGSStopGraphic(feature: <#AGSFeature!#>)
        self.mapView.addMapLayer(self.graphicsLayerStops, withName:"Stops")
        
        // initialize stop counter
        self.numStops = 0
        
        
        // update our banner
//        self.updateDirectionsLabel("Nothing to see here")
//        self.directionsLabel.hidden = false
//        
//        self.mapView.touchDelegate = self
//        self.isExecuting = false
        
        // add graphics layer for displaying the route
        var cs = AGSCompositeSymbol()
        var sls1 = AGSSimpleLineSymbol()
        sls1.color = UIColor.yellowColor()
        sls1.style = .Solid
        sls1.width = 8
        cs.addSymbol(sls1)
        var sls2 = AGSSimpleLineSymbol()
        sls2.color = UIColor.blueColor()
        sls2.style = .Solid
        sls2.width = 4
        cs.addSymbol(sls2)
        self.graphicsLayerRoute = AGSGraphicsLayer()
        self.graphicsLayerRoute.renderer = AGSSimpleRenderer(symbol: cs)
        self.mapView.addMapLayer(self.graphicsLayerRoute, withName:"Route")

    }
    
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    

    
    
    func mapView(mapView: AGSMapView!, didMoveTapAndHoldAtPoint screen: CGPoint, mapPoint mappoint: AGSPoint!, features: [NSObject : AnyObject]!) {
        if self.isExecuting {
            return
        }
        println("At adding mePOint to addStops, but in didTap func")
        //        var opsPoint1 = AGSPoint(fromDecimalDegreesString: "49.282 , -123.129", withSpatialReference:AGSSpatialReference.wgs84SpatialReference());
        
        var mePoint = AGSPoint(x: -13679000, y: 6300000, spatialReference: sr)
        self.addStop(mePoint)
        
        //        self.lastStop = self.addStop((AGSGeometryEngine.defaultGeometryEngine().projectGeometry(mePoint, toSpatialReference: self.mapView.spatialReference)) as AGSPoint);
        
        self.lastStop.geometry = mePoint
        if self.graphicsLayerStops.graphics.count < 2 {
            println("number of stops is less than 2")
            return
        }
        self.isExecuting = true
        self.solveRoute()
    }
    
    func mapViewDidLoad(mapView: AGSMapView!) {
        
        println("At adding newPoint to addStop")
        
        for var i = 0; i < 5; i++ {
            var newPoint = AGSPoint(x: empX[i], y: empY[i], spatialReference:sr)
            println(empX[i])
            self.addStop((AGSGeometryEngine.defaultGeometryEngine().projectGeometry(newPoint, toSpatialReference: self.mapView.spatialReference)) as AGSPoint);
        }
        
        
        
        var mePoint = AGSPoint(x: -13705500, y: 6320500, spatialReference: sr)
        self.lastStop = self.addStop((AGSGeometryEngine.defaultGeometryEngine().projectGeometry(mePoint, toSpatialReference: self.mapView.spatialReference)) as AGSPoint);
        
        if self.routeTaskParams != nil {
            self.routeTaskParams.outSpatialReference = self.mapView.spatialReference;
        }
        
        mapView.zoomIn(false);
    }

    //
    // we got the default parameters from the service
    //
    func routeTask(routeTask: AGSRouteTask!, operation op: NSOperation!, didRetrieveDefaultRouteTaskParameters routeParams: AGSRouteTaskParameters!) {
        self.routeTaskParams = routeParams
        
        self.routeTaskParams.returnRouteGraphics = true
        
        // this returns turn-by-turn directions
        self.routeTaskParams.returnDirections = true
        
        self.routeTaskParams.findBestSequence = true
        
        self.routeTaskParams.impedanceAttributeName = "Time"
        self.routeTaskParams.accumulateAttributeNames = ["Length", "Time"]
        
        // since we used "findBestSequence" we need to
        // get the newly reordered stops
        self.routeTaskParams.returnStopGraphics = false
        
        // ensure the graphics are returned in our map's spatial reference
        self.routeTaskParams.outSpatialReference = self.mapView.spatialReference
        
        // let's ignore invalid locations
        self.routeTaskParams.ignoreInvalidLocations = true
    }
    
    //
    // an error was encountered while getting defaults
    //
    func routeTask(routeTask: AGSRouteTask!, operation op: NSOperation!, didFailToRetrieveDefaultRouteTaskParametersWithError error: NSError!) {
        // Create an alert to let the user know the retrieval failed
        dispatch_async(dispatch_get_main_queue(), { () -> Void in
            UIAlertView(title: "Error", message: "Failed to retrieve default route parameters", delegate: nil, cancelButtonTitle: "OK").show()
            println("Failed to retrieve default route parameters: \(error)")
        })
    }
    
    //
    // route was solved
    //
    func routeTask(routeTask: AGSRouteTask!, operation op: NSOperation!, didSolveWithResult routeTaskResult: AGSRouteTaskResult!) {
        //rtPassVal = 0
        // update our banner with status
        //self.updateDirectionsLabel("Routing completed")
        
        // we know that we are only dealing with 1 route...
        self.routeResult = routeTaskResult.routeResults.last as AGSRouteResult;
        
        var resultSummary = "\(self.routeResult.totalMinutes) mins, \(self.routeResult.totalMiles) miles";
        println(resultSummary)
        
        
        
        if timeCount == 0 {
            println("the time count is:")
            println(timeCount)
            println(self.routeResult.totalMinutes)
            println(routeTime.capacity)
            routeTime[0] = self.routeResult.totalMinutes;
            println(routeTime[0]);
            timeCount++
            solveRoute()
        }
        else if timeCount == 1 {
            println("the time count is:")
            println(timeCount)
            println(self.routeResult.totalMinutes)
            println(routeTime.capacity)
            routeTime[0] = self.routeResult.totalMinutes;
            println(routeTime[0]);
            timeCount++
            solveRoute()
        }
        else if timeCount == 2 {
            println("the time count is:")
            println(timeCount)
            println(self.routeResult.totalMinutes)
            println(routeTime.capacity)
            routeTime[0] = self.routeResult.totalMinutes;
            println(routeTime[0]);
            timeCount++
            solveRoute()
        }
        else if timeCount == 3 {
            println("the time count is:")
            println(timeCount)
            println(self.routeResult.totalMinutes)
            println(routeTime.capacity)
            routeTime[0] = self.routeResult.totalMinutes;
            println(routeTime[0]);
            timeCount++
            solveRoute()
        }
        else if timeCount == 4 {
            println("the time count is:")
            println(timeCount)
            println(self.routeResult.totalMinutes)
            println(routeTime.capacity)
            routeTime[0] = self.routeResult.totalMinutes;
            println(routeTime[0]);
            timeCount++
            solveRoute()
        }
        else if timeCount == 5 {
            println("the time count is:")
            println(timeCount)
            println(self.routeResult.totalMinutes)
            println(routeTime.capacity)
            routeTime[0] = self.routeResult.totalMinutes;
            println(routeTime[0]);
            timeCount++
        }
        
        routeTime[rtPassVal] = self.routeResult.totalMinutes;
        println(self.routeResult.totalMinutes);
        
        println("the route pass count is: ")
        println(rtPassVal)
        //self.updateDirectionsLabel(resultSummary)
        
        // this is the return to the for loop
        
        
        // add the route graphic to the graphic's layer
        self.graphicsLayerRoute.removeAllGraphics()
        self.graphicsLayerRoute.addGraphic(self.routeResult.routeGraphic)
        
        
        // enable the next button so the user can traverse directions
        //self.nextBtn.enabled = true
        
        if self.routeResult.stopGraphics != nil {
            self.graphicsLayerStops.removeAllGraphics()
            
            for reorderedStop in self.routeResult.stopGraphics as [AGSStopGraphic] {
                var exists:ObjCBool = false
                var sequence = UInt(reorderedStop.attributeAsIntegerForKey("Sequence", exists: &exists))
                
                // create a composite symbol using the sequence number
                reorderedStop.symbol = self.stopSymbolWithNumber(sequence)
                
                // add the graphic
                self.graphicsLayerStops.addGraphic(reorderedStop)
            }
            
            self.routeTaskParams.findBestSequence = false
            self.routeTaskParams.returnStopGraphics = false
        }
        self.isExecuting = false
    }
    
    //
    // solve failed
    //
    func routeTask(routeTask: AGSRouteTask!, operation op: NSOperation!, didFailSolveWithError error: NSError!) {
        //self.updateDirectionsLabel("Routing failed")
        
        // the solve route failed...
        // let the user know
        
        UIAlertView(title: "Solve Route Failed", message: error.localizedDescription, delegate: nil, cancelButtonTitle: "OK").show()
    }
    
    //
    // create a composite symbol with a number
    //
    func stopSymbolWithNumber(stopNumber:UInt) -> AGSCompositeSymbol {
        var cs = AGSCompositeSymbol()
        
        // create outline
        var sls = AGSSimpleLineSymbol()
        sls.color = UIColor.blackColor()
        sls.width = 2
        sls.style = .Solid
        
        // create main circle
        var sms = AGSSimpleMarkerSymbol()
        sms.color = UIColor.greenColor()
        sms.outline = sls
        sms.size = CGSizeMake(20, 20)
        sms.style = .Circle
        cs.addSymbol(sms)
        
        //    // add number as a text symbol
        var ts = AGSTextSymbol(text: "\(stopNumber)", color: UIColor.blackColor())
        ts.vAlignment = .Middle
        ts.hAlignment = .Center
        ts.fontSize	= 16
        cs.addSymbol(ts)
        
        return cs
    }

    //
    // represents the current direction
    //
    func currentDirectionSymbol() -> AGSCompositeSymbol {
        var cs = AGSCompositeSymbol()
        
        var sls1 = AGSSimpleLineSymbol()
        sls1.color = UIColor.whiteColor()
        sls1.style = .Solid
        sls1.width = 8
        cs.addSymbol(sls1)
        
        var sls2 = AGSSimpleLineSymbol()
        sls2.color = UIColor.redColor()
        sls2.style = .Dash
        sls2.width = 4
        cs.addSymbol(sls2)
        
        return cs
    }
    
    //
    // update our banner's text
    //
//    func updateDirectionsLabel(newLabel:String) {
//        self.directionsLabel.text = newLabel
//    }
    
    func addStop(geometry:AGSPoint) -> AGSGraphic {
        
        //grab the geometry, then clear the sketch
        //Prepare symbol and attributes for the Stop/Barrier
        self.numStops++
        println("number of stops: ")
        println(numStops)
        
        var symbol = self.stopSymbolWithNumber(self.numStops)
        var stopGraphic = AGSStopGraphic(geometry: geometry, symbol:symbol, attributes:nil)
        stopGraphic.sequence = self.numStops
        
        //You can set additional properties on the stop here
        //refer to the conceptual helf for Routing task
        self.graphicsLayerStops.addGraphic(stopGraphic)
        return stopGraphic
    }
    //
    // perform the route task's solve operation
    //
    
    func solveRoute() {
        println("at solve route")
        //self.resetDirections()
        
        var stops = [AGSStopGraphic]()
        var i:Int = 0
        
        // get the stop, barriers for the route task
        for graphic in self.graphicsLayerStops.graphics as [AGSGraphic] {
            
            // if it's a stop graphic, add the object to stops
            
            if graphic is AGSStopGraphic {
                
                stops.append(graphic as AGSStopGraphic)
                
                println(stops.count)
                
            }
        }
        //println(stops[1])
        // set the stop and polygon barriers on the parameters object
        if stops.count > 0 && timeCount < 5 {
            // update our banner
            //self.updateDirectionsLabel("Routing...")
            
            
            var pairStops = [AGSStopGraphic]()
            if timeCount == 0 {
                println("At solve time 1 and time count is")
                println(timeCount)
                pairStops.append(stops[0])
                pairStops.append(stops[5]) //hard coded but should be based on the number of stops count
                println("solve first pass")
            }
            else {
                println("at else, with time count = ")
                println(timeCount)
                pairStops.removeAll(keepCapacity: false)
                pairStops.append(stops[timeCount])
                pairStops.append(stops[5])
                println("at solve pass: ")
                println(solveCount)
                
            }
            println("routeTask is executing")
            self.routeTaskParams.setStopsWithFeatures(pairStops)
            // execute the route task
            self.routeTask.solveWithParameters(self.routeTaskParams)
            
        }
        
        solveCount++
        println()
        if solveCount > 4 {
            println("at solve count for the final time")
            println(solveCount)
            sortTimes()
        }
        
    }
    
    func sortTimes() {
        println("begin sort")
        println(routeTime[1])
        var sortingTimes:[Double] = [routeTime[0],routeTime[1],routeTime[2],routeTime[3],routeTime[4]]
        sortingTimes.sort({$0 < $1})
        println(sortingTimes)
    }
    
    //
    // reset the sample so we can perform another route)
    //
//    func reset() {
//        // set stop counter back to 0
//        println("at reset on loop")
//        println(solveCount)
//        self.numStops = 0
//        
//        // remove all graphics
//        self.graphicsLayerStops.removeAllGraphics()
//        self.graphicsLayerRoute.removeAllGraphics()
//        self.resetDirections()
//        self.updateDirectionsLabel("Tap & hold on the map to add stops")
//        //self.reorderBtn.enabled = false
//    }
    
//    func resetDirections() {
//        // disable the next/prev direction buttons
//        // reset direction index
//        self.directionIndex = 0
//        self.nextBtn.enabled = false
//        self.prevBtn.enabled = false
//        self.graphicsLayerRoute.removeGraphic(self.currentDirectionGraphic)
//    }
    
    
    // -------------------------  End Routing Task Code
    
    //Toolbar Actions
    
    @IBOutlet weak var introText: UIButton!
    @IBAction func introClose(sender: UIButton) {
        introText.hidden = true
        self.mapView.zoomToEnvelope(env, animated:true)
        //switch sender.selectedSegmentIndex {
        //case 0:
        //self.routeTaskParams.impedanceAttributeName = "Time"
        //break;
        //case 1:
        //self.routeTaskParams.impedanceAttributeName = "Length"
        //default:
        //break;
        //}
    //}
    self.solveRoute()
    }

    //Legend Display
    @IBAction func legendDisplay(sender: UIBarButtonItem) {
        if legendImage.hidden {
            legendImage.hidden = false
        }
        else {
            legendImage.hidden = true
        }
        aboutApp.hidden = true
        introText.hidden = true
        layerOne.hidden = true
        layerTwo.hidden = true
        layerThree.hidden = true
    }
    @IBAction func legendClose(sender: UIButton) {
        legendImage.hidden = true
    }
    
    //Layer Toggling Main
    @IBAction func layersMain(sender: UIBarButtonItem) {
        if layerOne.hidden {
            layerOne.hidden = false
            layerTwo.hidden = false
            layerThree.hidden = false
        }
        else {
            layerOne.hidden = true
            layerTwo.hidden = true
            layerThree.hidden = true        }
        aboutApp.hidden = true
        introText.hidden = true
        legendImage.hidden = true
    }
    
    //Layer Toggling Buttons
    
    //Hospital toggle
    @IBAction func hospitalToggle(sender: UIBarButtonItem) {
        if self.mapView.mapLayerForName("Hospitals") != nil{
            self.mapView.removeMapLayer(hospitalLayer)
        }
        else {
            self.mapView.addMapLayer(hospitalLayer, withName:"Hospitals")
        }
    }
    
    //Clinic toggle
    @IBAction func clinicToggle(sender: UIBarButtonItem) {
        if self.mapView.mapLayerForName("Clinics") != nil{
            self.mapView.removeMapLayer(clinicsLayer)
        }
        else {
            self.mapView.addMapLayer(clinicsLayer, withName:"Clinics")
        }
    }
    
    //Community Center toggle
    @IBAction func communityToggle(sender: UIBarButtonItem) {
        if self.mapView.mapLayerForName("CommunityCenter") != nil{
            self.mapView.removeMapLayer(communityCenterLayer)
        }
        else {
            self.mapView.addMapLayer(communityCenterLayer, withName:"CommunityCenter")
        }
    }
    
    //Staging Areas Toggle
    @IBAction func stagingToggle(sender: UIBarButtonItem) {
        if self.mapView.mapLayerForName("Disaster") != nil{
            self.mapView.removeMapLayer(disasterLayer)
        }
        else {
            self.mapView.addMapLayer(disasterLayer, withName:"Disaster")
        }
    }
    
    //Emergency Operations Toggle
    @IBAction func emergencyToggle(sender: UIBarButtonItem) {
        if self.mapView.mapLayerForName("Operations") != nil{
            self.mapView.removeMapLayer(operationsLayer)
        }
        else {
            self.mapView.addMapLayer(operationsLayer, withName:"Operations")
        }
    }
    
    //Fire Halls Toggle
    @IBAction func fireToggle(sender: UIBarButtonItem) {
        if self.mapView.mapLayerForName("FireHall") != nil{
            self.mapView.removeMapLayer(fireHallLayer)
        }
        else {
            self.mapView.addMapLayer(fireHallLayer, withName:"FireHall")
        }
    }
    
    //Police Stations Toggle
    @IBAction func policeToggle(sender: UIBarButtonItem) {
        if self.mapView.mapLayerForName("Police") != nil{
            self.mapView.removeMapLayer(policeLayer)
        }
        else {
            self.mapView.addMapLayer(policeLayer, withName:"Police")
        }
    }
    
    //Schools Toggle
    @IBAction func schoolsToggle(sender: UIBarButtonItem) {
        if self.mapView.mapLayerForName("Schools") != nil{
            self.mapView.removeMapLayer(schoolLayer)
        }
        else {
            self.mapView.addMapLayer(schoolLayer, withName:"Schools")
        }
    }
    
    
    
    
    
    
    
    
    
    //About this App
    
    @IBAction func aboutButton(sender: UIBarButtonItem) {
        if aboutApp.hidden {
            aboutApp.hidden = false
        }
        else {
            aboutApp.hidden = true
        }
        legendImage.hidden = true
        introText.hidden = true
        layerOne.hidden = true
        layerTwo.hidden = true
        layerThree.hidden = true
    }
    
    @IBAction func aboutClose(sender: UIButton) {
        aboutApp.hidden = true
    }
    

}
